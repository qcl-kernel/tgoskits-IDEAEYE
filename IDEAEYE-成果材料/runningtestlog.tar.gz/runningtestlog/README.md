# runningtestlog — 测试日志说明

日期：2026-08-24
环境：QEMU 6.2.0（`qemu-system-aarch64`）、aarch64-linux-gnu-gcc 11.4、FreeRTOS-Kernel/+TCP main
对象：FreeRTOS AXNET/1 TCP server（QEMU aarch64 `virt` 虚拟机），通过 SLIRP + `hostfwd :5000` 验证

本目录保存了整套验证的原始日志。每个文件对应一类测试，按顺序执行即可复现。

---

## 日志文件总览

| 文件 | 作用 | 验证对象 | 结果 |
|---|---|---|---|
| `01-cargo-test.log` | 主机集成测试 | AXNET/1 协议 + StarryOS 客户端状态机（无需 QEMU） | ✅ 9/9 |
| `02-guest-boot.log` | FreeRTOS guest 启动 | 调度器、virtio-net 驱动、DHCP 取址 | ✅ |
| `03-rtos-tester.log` | AXNET/1 server 全行为 | 握手 / CONTROL / 心跳回显 / 坏帧 ERROR / 周期 STATUS | ✅ 5/5 |
| `04-starry-client.log` | 端到端 RTT / 吞吐 | 100 请求 × 1024B 的延迟分布与有效吞吐 | ✅ 100% ACK |
| `05-guest-server.log` | guest 侧 server 视角 | server 实际收到并处理的 CONTROL / STATUS | ✅ |
| `README.md` | 本说明 | — | — |

---

## 1. `01-cargo-test.log` — 主机集成测试

**作用**：在宿主机上跑通 AXNET/1 协议单测和客户端状态机，不依赖 QEMU，是最快的一层验证。

**内容**：
```
running 4 tests ... ok. 4 passed   ← axnet1 协议：CRC 校验值、帧编码/解码、坏帧检测
running 5 tests ... ok. 5 passed   ← loopback 集成：C/Rust 黄金帧一致、正常会话、
                                       分帧、断连重连、超时恢复
```

**查看**：
```bash
cat runningtestlog/01-cargo-test.log
```

**复现**：
```bash
cd tools/starry-rtos-net && cargo test --workspace
```

## 2. `02-guest-boot.log` — FreeRTOS guest 启动

**作用**：确认固件在 QEMU 里正常启动：BSP、virtio-net 驱动、DHCP 拿到地址、AXNET server 监听。

**内容**：
```
[bsp] GICv2 enabled (timer PPI=30, virtio SPI 32..63)
[netif] virtio-net ok mac=02:00:00:00:01:03 link=1
[axnet1] AXNET1_SERVER_READY ip=192.168.100.3 port=5000
vDHCPProcess: offer a00020fip for MAC address 01-03   ← DHCP 分配 10.0.2.15
```

**查看**：
```bash
cat runningtestlog/02-guest-boot.log
```

**复现**：
```bash
./tools/starry-rtos-net/host/rtos-standalone.sh   # 前台运行，串口打屏
```

## 3. `03-rtos-tester.log` — AXNET/1 server 全行为

**作用**：从宿主机作为 AXNET 客户端，逐项验证 server 的每个行为点。

**内容**：
```
[rtos-tester] PASS handshake CONTROL_ACK      ← CONTROL(START) → CONTROL_ACK
[rtos-tester] PASS control payload ack        ← 带 payload 的 CONTROL → ACK
[rtos-tester] PASS heartbeat echo             ← HEARTBEAT → 回显
[rtos-tester] PASS bad-crc ERROR (code=0x4)   ← 篡改帧 → 回 ERROR(BAD_CRC)
[rtos-tester] PASS periodic STATUS (state=RUNNING)  ← server 每 2s 推 STATUS
[rtos-tester] RESULT=PASS
```

**查看**：
```bash
cat runningtestlog/03-rtos-tester.log
```

**复现**（需先启动 guest）：
```bash
cd tools/starry-rtos-net && cargo run -p rtos-tester
```

## 4. `04-starry-client.log` — 端到端 RTT / 吞吐

**作用**：用正式客户端程序打 100 个 CONTROL 请求，统计成功率、RTT 分布（p50/p95/p99/max）、有效吞吐。

**内容**：
```
[starry-client] session sent=100 acked=100 errors=0 timeouts=0 reconnects=0
[starry-client] p50_rtt_us=913
[starry-client] p95_rtt_us=2045677
[starry-client] max_rtt_us=2049878
[starry-client] throughput_bytes=102400 throughput_us=95929885
[starry-client] RESULT=PASS
```

**说明**：p50 ≈ 0.9 ms 是正常局域网/模拟延迟；尾部 ~2 s 尖峰来自 SLIRP 转发重传，换 TAP 桥接后消失。

**查看**：
```bash
cat runningtestlog/04-starry-client.log
```

**复现**（需先启动 guest）：
```bash
cd tools/starry-rtos-net && cargo run -p starry-client -- --server 127.0.0.1 --port 5000 --requests 100 --payload 1024
```

## 5. `05-guest-server.log` — guest 侧 server 视角

**作用**：从 server 端确认它真的收到了连接和请求（与 tester/client 的日志互证）。

**内容**：
```
[axnet1] client connected from ...:port
[axnet1] CONTROL seq=164 plen=1024
[axnet1] push STATUS (RUNNING)
```

**查看**：
```bash
cat runningtestlog/05-guest-server.log
```

**复现**：以上命令跑完自然产生；guest 串口日志完整版在 QEMU 的 `-serial file:` 输出里。

---

## 验证结论

- FreeRTOS + FreeRTOS+TCP + virtio-net + AXNET/1 server 全链路在 QEMU 上通过；
- 主机测试 9/9、server 行为 5/5、100 请求 100% ACK；
- 未验证项：TAP/br0 双 QEMU 桥接（需 root）、StarryOS 侧 client 注入。
